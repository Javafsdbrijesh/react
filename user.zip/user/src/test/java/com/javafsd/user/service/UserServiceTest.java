package com.javafsd.user.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.javafsd.user.entity.User;

@SpringBootTest
class UserServiceTest {

	@Autowired
	private UserService userServices;
	
	@BeforeEach
	public void setUp() {
		
	}
	
	public void whenValidUserNAme_thenUserShouldFound() {
		
		Long userId = 2L;
		
		//User found = userServices.getUserWithDepartment(userId);
		
		
	}

}
