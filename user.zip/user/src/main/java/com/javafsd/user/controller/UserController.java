package com.javafsd.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javafsd.user.entity.User;
import com.javafsd.user.service.UserService;
import com.javafsd.user.vo.ResponseTemplateVO;

@RestController
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@PostMapping("/")
	public User saveUser(@RequestBody User user) {
		return userService.save(user);
		
	}
	
	@GetMapping("/{id}")
	public ResponseTemplateVO getUserWithDepatment(@PathVariable("id") Long userId) {
		return userService.getUserWithDepartment(userId);
	}
	
}
