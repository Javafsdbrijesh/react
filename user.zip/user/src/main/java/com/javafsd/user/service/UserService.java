package com.javafsd.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.javafsd.user.entity.User;
import com.javafsd.user.repository.UserRepository;
import com.javafsd.user.vo.Department;
import com.javafsd.user.vo.ResponseTemplateVO;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private RestTemplate restTemplate;

	public User save(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	public ResponseTemplateVO getUserWithDepartment(Long userId) {
		
		ResponseTemplateVO viewObject = new ResponseTemplateVO();
		User user = userRepository.findByUserId(userId);
		
		//Department department = restTemplate.getForObject("http://localhost:9001/departments/"+ user.getDepartmentId(), Department.class);
		Department department = restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/"+ user.getDepartmentId(), Department.class);
		viewObject.setUser(user);
		viewObject.setDepartment(department);
		
		return viewObject;
	}

}
