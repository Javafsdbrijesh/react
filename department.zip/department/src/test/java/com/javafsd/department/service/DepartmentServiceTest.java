/**
 * 
 */
package com.javafsd.department.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.javafsd.department.entity.Department;
import com.javafsd.department.repository.DepartmentRepository;


@SpringBootTest
class DepartmentServiceTest {
	
	@Autowired
	private DepartmentService departmentService;
	
	@MockBean
	private DepartmentRepository departmentRepository;

	@BeforeEach
	void setUp(){
		Department department = 
				Department.builder()
				.departmentId(1L)
				.departmentName("HR")
				.departmentAddress("Noida")
				.departmentCode("1")
				.build();
		Mockito.when(departmentRepository.findByDepartmentId(1L))
		.thenReturn(department);
	}

	@Test
	public void whenDepartmentId_thenDepartmentShouldFound() {
		Long departmentID  = 2L;
		
		Department found = departmentService.findDepartmentById(departmentID);
		assertEquals(departmentID, departmentID);
	}

}
